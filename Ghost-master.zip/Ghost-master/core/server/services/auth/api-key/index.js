module.exports = {
    get content() {
        return require('./content');
    }
};
