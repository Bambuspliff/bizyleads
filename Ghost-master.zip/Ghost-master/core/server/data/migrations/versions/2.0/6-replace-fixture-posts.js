const Promise = require('bluebird');

// @NOTE: the logic of this migration script was removed.
module.exports.up = () => {
    return Promise.resolve();
};

module.exports.down = () => {
    return Promise.resolve();
};
