module.exports = {
    get middlewares() {
        return require('./middlewares');
    },

    get utils() {
        return require('./utils');
    }
};
