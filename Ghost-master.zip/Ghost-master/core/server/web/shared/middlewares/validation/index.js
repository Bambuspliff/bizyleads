module.exports = {
    get upload() {
        return require('./upload');
    },

    get blogIcon() {
        return require('./blog-icon');
    },

    get profileImage() {
        return require('./profile-image');
    }
};
